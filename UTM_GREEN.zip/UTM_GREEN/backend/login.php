<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === "PTJ01" && $password === "123456") {
        $_SESSION['loggedin'] = true;
        header("Location: ../dashboard/dashboard.html");
        exit;
    } else {
        header("Location: LoginPage.html?error=1");
        exit;
    }
}
?>
